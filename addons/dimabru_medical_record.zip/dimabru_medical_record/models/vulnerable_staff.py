# -*- coding: utf-8 -*-

from openerp import models, fields, api

class VulnerableStaff(models.Model):
    _name = 'vulnerable.staff'

    minor_18 = fields.Boolean(string='Under 18 years old')
    disability = fields.Boolean(string='Disability')
    pregnancy = fields.Boolean(string='Pregnancy')
    description = fields.Char(string="Description")
    vulnerable_staff_ids = fields.One2many('medical.record', 'vulnerable_staff_id', string='Vulnerable Staff')