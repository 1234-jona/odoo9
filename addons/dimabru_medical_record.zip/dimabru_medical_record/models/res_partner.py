# -*- coding: utf-8 -*-

from openerp import models, fields, api

class ResPartner(models.Model):
    _inherit = 'res.partner'

    medical_partner_id = fields.Many2one('medical.record', string='Medical Record')