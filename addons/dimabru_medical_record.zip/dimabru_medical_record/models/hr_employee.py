# -*- coding: utf-8 -*-

from openerp import models, fields, api

class HrEmployee(models.Model):
    _inherit = 'hr.employee'

    medical_employee_id = fields.Many2one('medical.record', string='Medical Record')
   
    
