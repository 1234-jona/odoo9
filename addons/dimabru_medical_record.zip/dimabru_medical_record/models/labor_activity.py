# -*- coding: utf-8 -*-

from openerp import models, fields, api

class LaboralActivity(models.Model):
    _name = 'activity.laboral'

    company = fields.Char(string='Company')
    start_date = fields.Char(string='Departure entry date')
    end_date = fields.Char(string='Fecha de Salida')
    job_position = fields.Char(string='Job position')
    labor_risks = fields.Char(string='Occupational hazards')
    description = fields.Text(string='Description')
