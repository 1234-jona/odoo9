# -*- coding: utf-8 -*-

from openerp import models, fields, api

class Aptitude(models.Model):
    _name = 'aptitude'

    suitable = fields.Boolean(string='Suitable')
    suitable_restrictions = fields.Boolean(string='suitable with restrictions')
    unfit = fields.Boolean(string='Unfit')
    description = fields.Char(string="Description")