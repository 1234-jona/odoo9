# -*- coding: utf-8 -*-

from openerp import models, fields, api

class RiskPositions(models.Model):
    _name = 'risk.positions'

    risk_factors = fields.Char(string='Risk factor')
    charge_time = fields.Char(string='Charge Time')
    ergonomic = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='ergonomic')
    physical = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='physical')
    chemical = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='chemical')
    psychosocial = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='psychosocial')
    biological = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='biological')
    mechanic = fields.Selection([
        ('high', 'High'),
        ('half', 'Half'),
        ('low', 'Low')
    ], string='mechanic')
    description = fields.Char(string='description')
    risks_put_ids = fields.One2many('medical.record', 'risks_put_id', string='Risks put')
