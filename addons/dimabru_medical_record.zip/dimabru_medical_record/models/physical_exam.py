# -*- coding: utf-8 -*-

from openerp import models, fields, api

class PhysicalExamination(models.Model):
    _name = 'physical.exam'

    presion_arterial = fields.Char(string='Blood pressure')
    temperatura = fields.Char(string='temperature')
    frecuencia_cardiaca = fields.Char(string='Heart rate')
    frecuencia_respiratoria = fields.Char(string='Frequency respiratory')
    peso = fields.Char(string='Weight')
    talla = fields.Char(string='Size')
    imc = fields.Char(string='IMC')
    #inspeccion = fields.Text(string='Inspección')
    cabeza = fields.Text(string='Head')
    ojos = fields.Text(string='Eyes')
    oidos = fields.Text(string='Ears')
    nariz = fields.Text(string='Nose')
    boca = fields.Text(string='Mouth')
    orofaringe = fields.Text(string='Oropharynx')
    cuello = fields.Text(string='Neck')
    tiroides = fields.Text(string='Thyroid')
    torax = fields.Text(string='Chest')
    corazon = fields.Text(string='Heart')
    pulmones = fields.Text(string='Lungs')
    abdomen = fields.Text(string='Abdomen')
    genitourinario = fields.Text(string='Genitourinary')
    extremidades_superiores = fields.Text(string='Superior limbs')
    extremidades_inferiores = fields.Text(string='Lower extremities')
    columna = fields.Text(string='Column')
    neurologico = fields.Text(string='Neurological')
    piel_faneras = fields.Text(string='Skin faneras')
    vascular_periferico = fields.Text(string='Vascular peripheral')
    description = fields.Char(string="Description")

