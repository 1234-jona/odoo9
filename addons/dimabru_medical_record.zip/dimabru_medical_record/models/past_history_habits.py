# -*- coding: utf-8 -*-

from openerp import models, fields, api

class PastHistoryHabits(models.Model):
    _name = 'history.past.habits'

    feeding = fields.Char(string='Feeding')
    alcohol = fields.Char(string='Alcohol')
    tobacco = fields.Char(string='Tobacco')
    drugs = fields.Char(string='Drugs')
    medicines = fields.Char(string='Medicines')
    exercise = fields.Char(string='Exercise')
    sleep_hours = fields.Selection([
        ('1', '1 hours'),
        ('2', '2 hours'),
        ('3', '3 hours'),
        ('4', '4 hours'),
        ('5', '5 hours'),
        ('6', '6 hours'),
        ('7', '7 hours'),
        ('8', '8 hours'),
        ('9', '9 hours'),
        ('10', '10 hours')
    ], string='I sleep in hours ')
    allergies = fields.Char(string='Allergies')
    past_habits_id = fields.Many2one('medical.record', string='Past Habits')