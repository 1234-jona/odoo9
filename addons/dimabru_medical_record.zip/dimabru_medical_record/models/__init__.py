# -*- coding: utf-8 -*-

import medical_record
import hr_employee
import res_partner
import past_history_habits
import past_history_personal
import background_gynecological
import complementary_examen
import history_family
import labor_activity
import physical_exam
import social_history
import aptitude
import risks_put
import vulnerable_staff
