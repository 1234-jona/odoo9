# -*- coding: utf-8 -*-

from openerp import models, fields, api

class SocialHistory(models.Model):
    _name = 'history.social'

    company = fields.Char(string='Company')
    work_schedule = fields.Char(string='Tiempo de Trabajo')
    job_position = fields.Char(string='Working time')
    health_risks = fields.Char(string='Health Risks')
    work_accidents = fields.Char(string='Work accidents')
    suspected_work_related_illness = fields.Char(string='Suspected Occupational Disease')
    description = fields.Text(string='Description')