# -*- coding: utf-8 -*-

from openerp import models, fields, api

class BackgroundGynecological(models.Model):
    _name = 'background.gynecological'
    
    menarche = fields.Char(string='Menarche')
    pap_test = fields.Char(string='Pap Test')
    period = fields.Char(string='Period')
    family_planning = fields.Char(string='Family Planning')