# -*- coding: utf-8 -*-

from openerp import models, fields, api

class FamilyHistory(models.Model):
    _name = 'history.family'

    cardiopathy = fields.Char(string='Cardiopathy')
    vascular = fields.Char(string='Vascular')
    cancer = fields.Char(string='Cancer')
    mental_health = fields.Char(string='Mental Health')
    diabetes = fields.Char(string='Diabetes')
    hypertension = fields.Char(string='Hypertension')
    tuberculosis = fields.Char(string='Tuberculosis')
    description = fields.Text(string='description')