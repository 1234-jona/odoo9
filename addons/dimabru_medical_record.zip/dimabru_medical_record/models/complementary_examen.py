# -*- coding: utf-8 -*-

from openerp import models, fields, api
import string

class ComplementaryExam(models.Model):
    _name = 'exam.complementary'
    
    type_examen = fields.Selection([
        ('hematological','Hematological'),
        ('chemical','Chemical'),
        ('urinalysis','Urinalysis'),
        ('coprological','Coprological'),
        ])
    date_examen = fields.Date(string='Date examen')
    description = fields.Char(string='Description')
    #examen especiales
    requested_study = fields.Char(strimg='Special exam')
    requested_exam_date = fields.Date(string='Special exam date')
    description_examen_special = fields.Char(string='Special exam description')