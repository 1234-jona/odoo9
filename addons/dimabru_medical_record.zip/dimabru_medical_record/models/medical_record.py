# -*- coding: utf-8 -*-

from openerp import models, fields, api

class MedicalRecord(models.Model):
    _name = 'medical.record'

    name = fields.Char(string='Name')
    employee_ids = fields.One2many('hr.employee', 'medical_employee_id', string='Employees')
    partner_id = fields.Many2one('res.partner', string='Partner')
    past_habits_ids = fields.One2many('history.past.habits','past_habits_id', string='Past Habits')
    past_personal_id = fields.Many2one('history.past.personal',string='Past Personal' )
    history_family_id = fields.Many2one('history.family',string='History Family')
    history_social_id = fields.Many2one('history.social',string='History Social')
    activity_laboral_id = fields.Many2one('activity.laboral',string='Activity Laboral')
    background_gynecological_id = fields.Many2one('background.gynecological', string='Background Gynecological')
    physical_exam_id = fields.Many2one ('physical.exam',string='Exam Physical')
    exam_complementary_id = fields.Many2one ('exam.complementary',string='Exam Complementary')
    risks_put_id = fields.Many2one ('risks.put',string='Risks put')
    vulnerable_staff_id = fields.Many2one('vulnerable.staff',string='Vulnerable Staff')
    aptitude_id = fields.Many2one('aptitude',string='Aptitude') 
    partner_ids = fields.One2many('medical.record', 'partner_id', string='Partners')
    birth_place = fields.Char(string="Patient's birthplace")
    blood_type = fields.Selection([
        ('A+', 'A+'),
        ('A-', 'A-'),
        ('B+', 'B+'),
        ('B-', 'B-'),
        ('AB+', 'AB+'),
        ('AB-', 'AB-'),
        ('O+', 'O+'),
        ('O-', 'O-'),
    ], string='Blood Type')
    name_familiy = fields.Char(string='Family members name')
    relationship = fields.Char(string='Relationship with the family member')
    family_phone = fields.Char(string="Family number")
    type_doses = fields.Selection([
        ('covid','Covid'),
        ('diphtheria','Diphtheria'),
        ('tetanus','Tetanus')
        ],string="Type of dose the patient will receive")
    number_doses = fields.Char(string="Number of doses")
    date_doses = fields.Date(string="Dose date")
    apparatus_respiratory = fields.Boolean()
    apparatus_circulatory = fields.Boolean()
    apparatus_digestive = fields.Boolean()
    apparatus_urogenital = fields.Boolean()
    apparatus_endocrine = fields.Boolean()
    apparatus_strung = fields.Boolean()
    apparatus_musculoskeletal = fields.Boolean()
    apparatus_senses = fields.Boolean()

    

