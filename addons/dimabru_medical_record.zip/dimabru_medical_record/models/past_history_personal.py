# -*- coding: utf-8 -*-

from openerp import models, fields, api

class PastHistoryPersonal(models.Model):
    _name = 'history.past.personal'

    neurological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Neurological', default='not_refer')
    otorhinolaryngology = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Otorhinolaryngology', default='not_refer')
    oftalmologicos = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Oftalmologicos', default='not_refer')
    respiratory = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Respiratory', default='not_refer')
    cardiological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Cardiological', default='not_refer')
    gastrointestinal = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Gastrointestinal', default='not_refer')
    genitourinary = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Genitourinary', default='not_refer')
    locomotives = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Locomotives', default='not_refer')
    vascular = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Vascular', default='not_refer')
    hematological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Hematological', default='not_refer')
    endocrinological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Endocrinological', default='not_refer')
    metabolic = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Metabolic', default='not_refer')
    traumatological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Traumatological', default='not_refer')
    surgical = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Surgical', default='not_refer')
    psychological = fields.Selection([
        ('not_refer', 'Does not refer'),
        ('yes_refer', 'Yes it refers')
    ], string='Psychological', default='not_refer')
 
    
